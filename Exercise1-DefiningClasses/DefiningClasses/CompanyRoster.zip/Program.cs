﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
	Dictionary<string, List<Employee>> company = new Dictionary<string, List<Employee>>();
	int n = int.Parse(Console.ReadLine());
	for (int e = 1; e <= n; e++)
	{
	    string[] employeeInfo = Console.ReadLine().Split();
	    string name = employeeInfo[0];
	    double salary = double.Parse(employeeInfo[1]);
	    string position = employeeInfo[2];
	    string department = employeeInfo[3];
	    Employee employee = new Employee(name, salary, position, department);
	    if (employeeInfo.Length >= 5)
	    {
		if (employeeInfo[4].Contains("@"))
		{
		    employee.Email = employeeInfo[4];
		    if (employeeInfo.Length == 6) employee.Age = int.Parse(employeeInfo[5]);
		}
		else
		{
		    employee.Age = int.Parse(employeeInfo[4]);
		    if (employeeInfo.Length == 6) employee.Email = employeeInfo[5];
		}
	    }
	    if (!company.ContainsKey(department)) company.Add(department, new List<Employee>());
	    company[department].Add(employee);
	}
	string bestDepartment = company
	    .OrderByDescending(c => c.Value.Select(e => e.Salary).Sum()).First().Key;
	Console.WriteLine($"Highest Average Salary: {bestDepartment}");
	foreach (var employee in company[bestDepartment].OrderByDescending(e => e.Salary))
	{
	    Console.WriteLine($"{employee.Name} {employee.Salary:F2} {employee.Email} {employee.Age}");
	}
    }
}
